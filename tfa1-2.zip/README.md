# Point-of-Sale (POS) System Foundations

**Course:** IT0049 - Web System Technologies  
**Assessments:** TFA1 & TFA2

## Project Overview

This web application is developed using CodeIgniter 4 to demonstrate MVC architecture, routing, dynamic views, and database integration across two phases:

- **Activity 1 (TFA1):** Created a 4-page website (Home, About, Customers, Users) using static PHP arrays for mock data storage.
- **Activity 2 (TFA2):** Migrated customer and staff records to a MySQL database using CodeIgniter Models (`CustomerModel`, `UserModel`) and Query Builder methods (`findAll()`).

## Application Routes

- `/` — POS Dashboard / Landing Page
- `/about` — About Page
- `/customers` — Customer Accounts (loaded from MySQL)
- `/users` — User Accounts (loaded from MySQL)

## Database Setup

1. Create a database named `ci4_pos` in MySQL / phpMyAdmin.
2. Import the schema and seed records from:
   ```text
   database/ci4_pos.sql
   ```
