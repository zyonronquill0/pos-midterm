<?= view('templates/header') ?>

<h2>Staff / User Accounts</h2>
<p>Internal authorized system users (loaded from MySQL Database via UserModel):</p>

<table>
    <thead>
        <tr>
            <th>#</th>
            <th>Username</th>
            <th>Full Name</th>
            <th>Created At</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($users)): ?>
        <?php foreach ($users as $index => $user): ?>
        <tr>
            <td><?= $index + 1 ?></td>
            <td><code><?= esc($user['username']) ?></code></td>
            <td><?= esc($user['full_name']) ?></td>
            <td><?= esc($user['created_at']) ?></td>
        </tr>
        <?php endforeach; ?>
        <?php else: ?>
        <tr>
            <td colspan="4" style="text-align: center;">No user records found.</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>

<?= view('templates/footer') ?>