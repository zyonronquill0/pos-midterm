<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'POS App') ?></title>
    <style>
    body {
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        margin: 0;
        background: #f8fafc;
        color: #334155;
    }

    header {
        background: #0f172a;
        padding: 16px 32px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        color: white;
    }

    header h1 {
        font-size: 18px;
        margin: 0;
    }

    nav a {
        color: #94a3b8;
        text-decoration: none;
        margin-left: 20px;
        font-weight: 500;
    }

    nav a:hover {
        color: #ffffff;
    }

    .content {
        max-width: 900px;
        margin: 40px auto;
        background: white;
        padding: 30px;
        border-radius: 8px;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    th,
    td {
        border: 1px solid #e2e8f0;
        padding: 12px 14px;
        text-align: left;
    }

    th {
        background: #f1f5f9;
        font-weight: 600;
    }

    tr:nth-child(even) {
        background: #f8fafc;
    }

    .tag {
        display: inline-block;
        background: #e0f2fe;
        color: #0369a1;
        padding: 3px 8px;
        border-radius: 4px;
        font-size: 13px;
        font-weight: 600;
    }
    </style>
</head>

<body>
    <header>
        <h1>POS System Foundations</h1>
        <nav>
            <a href="<?= base_url('/') ?>">Home</a>
            <a href="<?= base_url('/about') ?>">About</a>
            <a href="<?= base_url('/customers') ?>">Customers</a>
            <a href="<?= base_url('/users') ?>">Users</a>
        </nav>
    </header>
    <div class="content">