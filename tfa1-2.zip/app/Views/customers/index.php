<?= view('templates/header') ?>

<h2>Customer Accounts</h2>
<p>Registered customer directory (loaded from MySQL Database via CustomerModel):</p>

<table>
    <thead>
        <tr>
            <th>#</th>
            <th>Full Name</th>
            <th>Email Address</th>
            <th>Contact Number</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($customers)): ?>
        <?php foreach ($customers as $index => $customer): ?>
        <tr>
            <td><?= $index + 1 ?></td>
            <td><?= esc($customer['full_name']) ?></td>
            <td><?= esc($customer['email']) ?></td>
            <td><?= esc($customer['phone']) ?></td>
        </tr>
        <?php endforeach; ?>
        <?php else: ?>
        <tr>
            <td colspan="4" style="text-align: center;">No customer records found.</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>

<?= view('templates/footer') ?>